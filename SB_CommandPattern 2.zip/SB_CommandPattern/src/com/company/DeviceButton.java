package com.company;

public class DeviceButton {
}
