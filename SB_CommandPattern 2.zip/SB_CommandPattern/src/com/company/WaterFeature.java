package com.company;

public interface WaterFeature {

    public void on();
    public void off();
    public void jetsOn();
    public void jetsOff();
    public void circulate();
    public void setTemperature();

}
