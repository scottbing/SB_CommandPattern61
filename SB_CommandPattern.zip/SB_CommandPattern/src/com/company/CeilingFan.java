package com.company;

public class CeilingFan  implements ElectronicDevice{

    @Override
    public void on() {

    }

    @Override
    public void off() {

    }

    @Override
    public void volumeUp() {

    }

    @Override
    public void volumeDown() {

    }
}
