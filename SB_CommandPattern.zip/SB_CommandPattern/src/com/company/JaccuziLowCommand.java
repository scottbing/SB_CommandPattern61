package com.company;

public class JaccuziLowCommand {
}
