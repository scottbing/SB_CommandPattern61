package com.company;

public class JaccuziMediumCommand {
}
